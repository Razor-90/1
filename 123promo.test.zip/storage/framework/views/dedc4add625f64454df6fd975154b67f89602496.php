<!-- resources/views/promo_codes/edit.blade.php -->



<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>+ Promo Code</h1>

        <form action="<?php echo e(route('admin.promo_codes.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <label for="promo_code">Enter Promo Code:</label>
            <input type="text" name="promo_code" id="promo_code">
            <button type="submit">Add Promo Code</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
ц

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\promo.test\resources\views/admin/promo_codes/create.blade.php ENDPATH**/ ?>