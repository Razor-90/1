<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 50px;">
        <div class="row">
            <h1>Личный кабинет пользователя <?php echo e(auth()->user()->name); ?></h1>
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <div class="col">
                <form method="post" action="<?php echo e(route('user.checkPromoCode')); ?>">
                    <?php echo csrf_field(); ?>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Введите промокод" aria-label="Введите промокод"  id="promo_code" name="promo_code"  aria-describedby="button-addon2" required>
                    <button class="btn btn-outline-secondary" type="submit" id="button-addon2">Проверить</button>
                </div>
                </form>
            </div>
            <div class="col">
                <h2>Мои промокоды:</h2>
                <ol>
                    <?php $__currentLoopData = $promoCodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promoCode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($promoCode->code); ?> | <?php echo e($promoCode->promo_code_selection_date ?? 'Not Selected'); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            </div>

            <form method="post" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary">Выйти</button>
            </form>
        </div>
    </div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\promo.test\resources\views/home.blade.php ENDPATH**/ ?>