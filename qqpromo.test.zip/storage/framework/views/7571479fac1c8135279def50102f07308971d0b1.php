<?php $__env->startSection('content'); ?>
    <div class="container text-center" style="margin-top: 50px;>
        <div class="row">
            <div class="col">
                <h1>Добро пожаловать на сайт с промокодами!</h1>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('user.cabinet')); ?>">Личный кабинет</a>
                    <form method="post" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit">Выйти</button>
                    </form>
                <?php else: ?>
                    <a class="btn btn-primary" href="<?php echo e(route('login')); ?>">Вход</a> |
                    <a class="btn btn-primary" href="<?php echo e(route('register')); ?>">Регистрация</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\promo.test\resources\views/welcome.blade.php ENDPATH**/ ?>