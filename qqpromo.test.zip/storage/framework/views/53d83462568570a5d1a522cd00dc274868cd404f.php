<?php $__env->startSection('content'); ?>
    <h1>Bulk Create Promo Codes</h1>

    <form action="<?php echo e(route('promo_codes.storeBulkCSV')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="csv_file">CSV File:</label>
            <input type="file" name="csv_file" id="csv_file" required accept=".csv, .txt">
        </div>

        <button type="submit" class="btn btn-primary">Upload</button>
    </form>
    <form action="<?php echo e(route('promo_codes.upload')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="file" name="csv_file">
        <button type="submit">Upload CSV</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\promo.test\resources\views/admin/promo_codes/bulk_create_csv.blade.php ENDPATH**/ ?>