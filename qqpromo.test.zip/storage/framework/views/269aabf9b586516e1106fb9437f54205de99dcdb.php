<?php $__env->startSection('content'); ?>
    <h1>Промокоды</h1>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>ID</th>
            <th>Код</th>
            <th>ФИО</th>
            <th>Телефон</th>
            <th>Город</th>
            <th>Дата</th>

        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $usedPromoCodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promoCode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($promoCode->id); ?></td>
                <td><?php echo e($promoCode->code); ?></td>
                <td><?php echo e($promoCode->user->name ?? 'N/A'); ?></td> <!-- Access the associated user's name -->
                <td><?php echo e($promoCode->user->phone ?? 'N/A'); ?></td> <!-- Access the associated user's name -->
                <td><?php echo e($promoCode->user->city ?? 'N/A'); ?></td>
                <td><?php echo e($promoCode->promo_code_selection_date ?? 'Not Selected'); ?></td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <form action="<?php echo e(route('promo_codes.upload')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="file" name="csv_file">
        <button type="submit">Загрузить промокоды</button>
    </form>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\promo.test\resources\views/admin/promo_codes/index.blade.php ENDPATH**/ ?>